package com.roomroot.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomrootBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomrootBackendApplication.class, args);
	}

}
